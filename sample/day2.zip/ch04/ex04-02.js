// 표현식 방식의 함수 선언(익명함수)


console.log(add(10, 20));