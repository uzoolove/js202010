console.log(add(10, 20));

// 선언문 형식의 함수 정의


console.log(add(10, 20));
