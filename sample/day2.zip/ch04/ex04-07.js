console.log(add(10, 20));

// 표현식 형식의 함수 정의


console.log(add(10, 20));
