var name = 'global';
function returnName(){
	return this.name;
}

// 일반적인 함수로 호출(함수명())


// 객체의 메소드로 호출(객체.메소드명())


















