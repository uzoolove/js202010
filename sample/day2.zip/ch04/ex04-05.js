// Function 생성자 함수 이용


console.log(add(10, 20));